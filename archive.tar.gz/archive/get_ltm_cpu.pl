#! /usr/bin/perl -w

use strict; 
use Net::SNMP qw(:snmp);
use RRD::OO;
use Data::Dumper;

#
# Define Vars
#
#my $host            = $ARGV[0];
#my $snmpComm        = $ARGV[1];
my @hosts           = ('vip2c', 'vip2s1', 'vip2s2');
my $snmpComm        = 'public';
my $snmpVer         = 'snmpv2c';
my $rrdname         = '';
my $userCpuBase     = '.1.3.6.1.4.1.2021.11.9.0';
my $systemCpuBase   = '.1.3.6.1.4.1.2021.11.10.0';
my $idleCpuBase     = '.1.3.6.1.4.1.2021.11.11.0';
my $tmmTotalCyl     = '.1.3.6.1.4.1.3375.2.1.1.2.1.41.0';
my $tmmIdleCyl      = '.1.3.6.1.4.1.3375.2.1.1.2.1.42.0';
my $tmmSleepCyl     = '.1.3.6.1.4.1.3375.2.1.1.2.1.43.0';

my @cpuOids = ($tmmTotalCyl, $tmmIdleCyl, $tmmSleepCyl);


##
## Begin Main
##


# cycle through each host
foreach my $host (@hosts) {
  my ($session, $error) = Net::SNMP->session(
      -hostname     => $host,
      -community    => $snmpComm,
      -version      => $snmpVer,
      -maxmsgsize   => 8192,
      -nonblocking  => 0,
      );

  if (!defined($session)) {
    print STDERR "SNMP handler not initialiezed: ".$error."\n";
    exit 1;
  }

  my $polled_oids = $session->get_request( -varbindlist  => \@cpuOids);

  die($session->error()) if $session->error();

#  if(defined($polled_oids)) {
#    print STDERR Dumper($polled_oids);
#  }
#  else {
#    die("\$polled_oids not defined

  # calculate CPU utilization
  my $tmm_cpu = (( $polled_oids->{$tmmTotalCyl} - 
        ($polled_oids->{$tmmIdleCyl} + $polled_oids->{$tmmSleepCyl})) / 
        $polled_oids->{$tmmTotalCyl}) * 100;

  # bring it to an integer
  $tmm_cpu = int($tmm_cpu * .5);

  print "Host: ".$host."\tCPU: ".$tmm_cpu."\n";
#my $rrd = RRD::Simple->new(file => $rrdname );
#$rrd->create(  
    
