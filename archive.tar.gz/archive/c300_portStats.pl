#! /usr/bin/perl

## Required libraries
#
use warnings;
use strict;
use Getopt::Std;
use Net::SNMP qw(:snmp);
use Time::HiRes qw(usleep time clock);
use Spreadsheet::WriteExcel;
use Data::Dumper;

$!++;  # No buffer for STDOUT
## retrieve and process CLI paramters
#
our (%opts, $DATAOUT, $BYPASS, $DEBUG, $VERBOSE, $CUSTOMER, $TESTNAME, $COMMENTS);
getopts('d:l:o:C:T:m:c:s:i:BDvh', \%opts);


# print usage and exit
&usage(0) if $opts{'h'};

if (!$opts{'d'}) {
  warn("Must provide a hostname or IP address to query\n");
  &usage(1);
}

my $host      = $opts{'d'};                 # snmp host to poll
my $testLen   = $opts{'l'} || 140;          # total duration of test in seconds
my $xlsName   = $opts{'o'} || '/dev/null';  # output file name
my $snmpVer   = $opts{'s'} || 'v2c';        # snmp version
my $comm      = $opts{'c'} || 'public';     # community string    
my $cycleTime = $opts{'i'} || 4;            # polling interval

my $loopcnt   = 25;                         # controls frequency of column headers

if ($opts{'o'}) { $DATAOUT    = 1; }
if ($opts{'B'}) { $BYPASS     = 1; }
if ($opts{'D'}) { $DEBUG      = 1; }
if ($opts{'v'}) { $VERBOSE    = 1; }
if ($opts{'C'}) { $CUSTOMER   = $opts{'C'}; }
if ($opts{'T'}) { $TESTNAME   = $opts{'T'}; }
if ($opts{'m'}) { $COMMENTS   = $opts{'m'}; }

## normal vars
#
my $elapsed   = 0;       # total time test has been running
my %pollTimer = ();      # tracks the amount on time required for each poll operation


if ($DEBUG) {
  print Dumper(\%opts);
  print "DATAOUT:  ".$DATAOUT. "\n";
  print "BYPASS:   ".$BYPASS.  "\n";
  print "DEBUG:    ".$DEBUG.   "\n";
  print "VERBOSE:  ".$VERBOSE. "\n";
  print "CUSTOMER: ".$CUSTOMER."\n";
  print "TESTNAME: ".$TESTNAME."\n";
  print "COMMENTS: ".$COMMENTS."\n";
}

# additional constants
use constant MB       => 1024*1024;

##
## Initialization and environment check
##

$VERBOSE && print("Host: ".$host."\nDuration: ".$testLen." seconds\nFile: ".$xlsName."\n\n");

# Build the oid lists and varbind arrays
my (@dataList, @errorList, @staticList, @rowData);
my ($sleepTime, $dataVals, $errorVals, $testStart, $runTime);
my ($clientCurConns, $clientTotConns, $serverCurConns, $serverTotConns);
my ($cpuUsed, $cpuTicks, $cpuUtil, $cpuPercent, $memUsed);
my ($timeSpent, $pollRTT, $col, $row, $numRows);
my ($workbook, $summary, $raw_data, $rowTime, $rowCPU);
my (%formats);

my %staticOids  = &get_static_oids();
my %dataOids    = &get_f10_oids();
my %oldData     = ('int1BytesIn'    => 0,
                   'int1BytesOut'   => 0,
                   'int2BytesIn'    => 0,
                   'int2BytesOut'   => 0,
                  );
my @summaryHdrs = ('RunTime', 'cycleTime', 'Int1 bitsIn/sec', 'Int1 bitsOut/sec', 
                   'Int2 bitsIn/sec', 'Int2 bitsOut/sec'
                  );
my @rawdataHdrs = ('RunTime', 'Int1 bytesIn', 'Int1 bytesOut', 
                   'Int2 btyesIn', 'Int2 bytesOut', 
                  );

while (my ($key, $value) = each(%staticOids)) { push(@staticList, $value); }
while (my ($key, $value) = each(%dataOids))   { push(@dataList, $value); }

my ($session, $error) = Net::SNMP->session(
  -hostname     => $host,
  -community    => $comm,
  -version      => $snmpVer,
  -maxmsgsize   => 8192,
  -nonblocking  => 0,
);
die($error."\n") if ($error);


# Get the static datapoints and print them to STDOUT
my $result = $session->get_request( -varbindlist  => \@staticList);
while (my ($k, $v) = each(%staticOids)) { print $k.": ".$result->{$v}."\n"; }

# determine if logging is required and create the output files
if ($DATAOUT) {
  $DEBUG && print "Creating workbook...";
  ($workbook, $raw_data, $summary, %formats) = &mk_perf_xls($xlsName, \@rawdataHdrs, \@summaryHdrs);
}


##
## Begin Main
##

# loop until start-of-test is detected
&detect_test($session, \%dataOids) unless $BYPASS;

$testStart = Time::HiRes::time(); # start tracking time

# start active polling
while ($elapsed <= $testLen) {
  $pollTimer{'start'} = Time::HiRes::time();

  # get current statistics from DUT
  $pollTimer{'datapoll'} = Time::HiRes::time();
  $dataVals = $session->get_request( -varbindlist  => \@dataList);
  die($session->error."\n") if (!defined($dataVals));
  $pollTimer{'pollend'} = Time::HiRes::time();

  # If requested, write the output file.
  if ($DATAOUT) {
    $row++;
    $raw_data->write($row, 0, $runTime, $formats{'decimal4'});
    $raw_data->write($row, 1, $cpuPercent, $formats{'decimal2'});
    $raw_data->write($row, 
                      2, 
                      [
                      sprintf("%.0f", $dataVals->{$dataOids{'int1BytesIn'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'int1BytesOut'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'int2BytesIn'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'int2BytesOut'}})],

                     $formats{'standard'});
  }

  # print stats to STDOUT if requested
  if ($VERBOSE) {
    my $int1In    = ($dataVals->{$dataOids{'int1BytesIn'}}  - $oldData{'int1BytesIn'}) /$cycleTime;
    my $int1Out   = ($dataVals->{$dataOids{'int1BytesOut'}} - $oldData{'int1BytesOut'}) /$cycleTime;
    my $int2In    = ($dataVals->{$dataOids{'int2BytesIn'}}  - $oldData{'int2BytesIn'}) /$cycleTime;
    my $int2Out   = ($dataVals->{$dataOids{'int2BytesOut'}} - $oldData{'int2BytesOut'}) /$cycleTime;
    my $inRatio   = (($int2Out - $int1In) / $int2Out) * 100;
    my $outRatio  = (($int2In - $int1Out) / $int2In) * 100;

    format STDOUT_TOP =
      @>>>>>  @>>>>>>>>>>>> @>>>>>>>>>>>> @>>>>>>>>>>>> @>>>>>>>>>>>> @>>>>>>>> @>>>>>>>>
      "CPU", "int1BytesIn", "int2BytesOut", "int2BytesIn", "int1BytesOut", "In Ratio", "Out Ratio"
.

    format =
      @##.##% @############ @############ @############ @############ @####.## @####.##
      $cpuUtil, $int1In, $int2Out, $int2In, $int1Out, $inRatio, $outRatio
.
    write;

    $oldData{'int1BytesIn'}  = $dataVals->{$dataOids{'int1BytesIn'}};
    $oldData{'int1BytesOut'} = $dataVals->{$dataOids{'int1BytesOut'}};
    $oldData{'int2BytesIn'}  = $dataVals->{$dataOids{'int2BytesIn'}};
    $oldData{'int2BytesOut'} = $dataVals->{$dataOids{'int2BytesOut'}};
  }


  # Calculate how much time this polling cycle has required to determine how
  # long we should sleep before beginning the next cycle
  $pollTimer{'end'} = Time::HiRes::time();
  $runTime = $pollTimer{'end'} - $testStart;

  $pollRTT   = $pollTimer{'pollend'} - $pollTimer{'start'};
  $timeSpent = $pollTimer{'end'} - $pollTimer{'start'};
  $sleepTime = $cycleTime-$timeSpent;

  $loopcnt++;
  $elapsed += $cycleTime;
  usleep($cycleTime * 1000000);
} 


if ($DATAOUT) {
  # polling is now complete, time to write the summary formulas 
  &write_summary($summary, \%formats, $row);

  # close the workbook; required for the workbook to be usable.
  &close_xls($workbook);
}



##
## Subs
##

# delay the start of the script until the test is detected through pkts/sec
sub detect_test() {
  my $snmp = shift;
  my $oids = shift;
  my $pkts = 3000;

  print "Waiting for test to begin...";

  while (1) {
    my $r1 = $snmp->get_request($$oids{'int1BytesIn'});
    sleep(2);
    my $r2 = $snmp->get_request($$oids{'int1BytesIn'});

    my $delta = $r2->{$$oids{'int1BytesIn'}}- 
                $r1->{$$oids{'int1BytesIn'}};
  
    if ($delta > $pkts) {
      print "\nStart of test detected...\n";
      return;
    }
    else {
      print ".";
      sleep(3);
    }
  }
}

# write the formulas in the summary sheet. 
# IN:   $row  - number of data rows in 'raw_data' worksheet
# OUT:  nothing

sub write_summary() {
  my $summary = shift;
  my $formats = shift;
  my $numRows = shift;
  my ($row, $col, $r1, $r2, $cTime, $rowTime, $runDiff, $rowCPU);
  
  # columns in 'raw_data' sheet
  my %r = ('rowtime'      => 'A',
           'rowcpu'       => 'B',
           'memutil'      => 'C',
           'cltBytesIn'   => 'D',
           'cltBytesOut'  => 'E',
           'svrBytesIn'   => 'H',
           'svrBytesOut'  => 'I',
           'cltTotConns'  => 'M',
           'svrTotConns'  => 'O',
          );


  for ($row = 0; $row < $numRows; $row++) {
    $r1    = $row+1;
    $r2    = $row+2;

    $cTime   = 'raw_data!'.$r{'rowtime'}.$r2.'-raw_data!'.$r{'rowtime'}.$r1;

    # splitting these out is required so a different format can be applied to numbers
    $rowTime = '=raw_data!'.$r{'rowtime'}.$r2;
    $runDiff = '='.$cTime;
    $rowCPU  = '=raw_data!'.$r{'rowcpu'}.$r2;

    # @rowData contains formulas required to populate the summary data sheet.
    # In order, they are: memutil, client bits/sec in, client bits/sec out,
    #                     server bits/sec in, server bits/sec out, client conns/sec,
    #                     server conns/sec
    @rowData = (
      '=raw_data!'   .$r{'memutil'}.$r2,
      '=(((raw_data!'.$r{'cltBytesIn'} .$r2.'-raw_data!'.$r{'cltBytesIn'} .$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'cltBytesOut'}.$r2.'-raw_data!'.$r{'cltBytesOut'}.$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'svrBytesIn'} .$r2.'-raw_data!'.$r{'svrBytesIn'} .$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'svrBytesOut'}.$r2.'-raw_data!'.$r{'svrBytesOut'}.$r1.')/('.$cTime.'))*8)',
      '=((raw_data!' .$r{'cltTotConns'}.$r2.'-raw_data!'.$r{'cltTotConns'}.$r1.')/('.$cTime.'))',
      '=((raw_data!' .$r{'svrTotConns'}.$r2.'-raw_data!'.$r{'svrTotConns'}.$r1.')/('.$cTime.'))',
    );

    $DEBUG && print Dumper(\@rowData);
    $summary->write($row, 0, [$rowTime, $runDiff], ${$formats}{'decimal4'});
    $summary->write($row, 2, $rowCPU,   ${$formats}{'decimal2'});
    $summary->write($row, 3, \@rowData, ${$formats}{'standard'});
  }
}

## returns a has containing the data-oids
sub get_f10_oids() {
  my %oidlist = (
      'int1BytesIn'             => '.1.3.6.1.2.1.31.1.1.1.6.134547457',
      'int1BytesOut'            => '.1.3.6.1.2.1.31.1.1.1.10.134547457',
      'int2BytesIn'             => '.1.3.6.1.2.1.31.1.1.1.6.134809601',
      'int2BytesOut'            => '.1.3.6.1.2.1.31.1.1.1.10.134809601',
                );

  return(%oidlist);
}

# returns a hash containing oids that will be polled only once
sub get_static_oids() {
  my %oidlist = ( 'iosver'       => '.1.3.6.1.4.1.6027.3.8.1.1.3.0',
                  'platform'     => '.1.3.6.1.4.1.6027.3.8.1.1.1.0',
                  'uptime'  => '.1.3.6.1.4.1.6027.3.8.1.2.1.1.6.1',
                );

  return(%oidlist);
}

sub mk_perf_xls() {
  my $fname   = shift;
  my $rawHdrs = shift;
  my $sumHdrs = shift;
  my $r = 0;
  my $c = 0;
  my %hdrfmts;

  ## create Excel workbook
  my $workbook = Spreadsheet::WriteExcel->new($fname);

  # define formatting
  $hdrfmts{'headers'}  = $workbook->add_format(align => 'center', bold => 1, bottom => 1);
  $hdrfmts{'standard'} = $workbook->add_format(align => 'center', num_format => '#,##0');
  $hdrfmts{'decimal2'} = $workbook->add_format(align => 'center', num_format => '0.00');
  $hdrfmts{'decimal4'} = $workbook->add_format(align => 'center', num_format => '0.0000');

  # create worksheets
  my $summary = $workbook->add_worksheet('summary');
  $summary->set_column('A:C', 9);
  $summary->set_column('D:M', 17);
  $summary->activate();

  my $rawdata = $workbook->add_worksheet('raw_data');
  $rawdata->set_column('A:B', 9);
  $rawdata->set_column('C:Z', 15);

  $summary->write($r, $c, $sumHdrs, $hdrfmts{'headers'});
  $rawdata->write($r, $c, $rawHdrs, $hdrfmts{'headers'});

  return($workbook, $rawdata, $summary, %hdrfmts);
}

# Close the spreadsheet -- REQUIRED
sub close_xls() {
  my $xls = shift;

  $xls->close();

  return(1);
}


# print script usage and exit with the supplied status
sub usage() {
  my $code = shift;

  print <<END;
  USAGE:  $0 -d <host> -l <total test length> -o <output file>
          $0 -h

  -d      IP or hostname to query (REQUIRED)
  -l      Full Test duration             (default: 140 seconds)
  -i      Seconds between polling cycles (default: 4 seconds)
  -o      Output filename                (default: /dev/null)
  -h      Print usage and exit

END

  exit($code);
}
