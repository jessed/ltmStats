#! /usr/bin/perl

## Required libraries
#
use warnings;
use strict;
use Config;
use Getopt::Std;
use Net::SNMP qw(:snmp);
use Time::HiRes qw(usleep time clock);
use Spreadsheet::WriteExcel;
use Data::Dumper;

$!++;  # No buffer for STDOUT

## retrieve and process CLI paramters
#
our (%opts, $DATAOUT, $BYPASS, $DEBUG, $VERBOSE, $CUSTOMER, $TESTNAME, $COMMENTS);
getopts('d:l:o:C:T:m:c:s:i:BDvh', \%opts);


# print usage and exit
&usage(0) if $opts{'h'};

if (!$opts{'d'}) {
  warn("Must provide a hostname or IP address to query\n");
  &usage(1);
}

my $host      = $opts{'d'};                 # snmp host to poll
my $testLen   = $opts{'l'} || 140;          # total duration of test in seconds
my $xlsName   = $opts{'o'} || '/dev/null';  # output file name
my $snmpVer   = $opts{'s'} || 'v2c';        # snmp version
my $comm      = $opts{'c'} || 'public';     # community string    
my $cycleTime = $opts{'i'} || 4;            # polling interval

my $loopcnt   = 25;                         # controls frequency of column headers

if ($opts{'o'}) { $DATAOUT    = 1; }
if ($opts{'B'}) { $BYPASS     = 1; }
if ($opts{'D'}) { $DEBUG      = 1; }
if ($opts{'v'}) { $VERBOSE    = 1; }
if ($opts{'C'}) { $CUSTOMER   = $opts{'C'}; }
if ($opts{'T'}) { $TESTNAME   = $opts{'T'}; }
if ($opts{'m'}) { $COMMENTS   = $opts{'m'}; }

## normal vars
#
my $elapsed   = 0;       # total time test has been running
my %pollTimer = ();      # tracks the amount on time required for each poll operation


if ($DEBUG) {
  print Dumper(\%opts);
  print "DATAOUT:  ".$DATAOUT. "\n";
  print "BYPASS:   ".$BYPASS.  "\n";
  print "DEBUG:    ".$DEBUG.   "\n";
  print "VERBOSE:  ".$VERBOSE. "\n";
  print "CUSTOMER: ".$CUSTOMER."\n";
  print "TESTNAME: ".$TESTNAME."\n";
  print "COMMENTS: ".$COMMENTS."\n";
}

# additional constants
use constant MB       => 1024*1024;

##
## Initialization and environment check
##

$VERBOSE && print("Host: ".$host."\nDuration: ".$testLen." seconds\nFile: ".$xlsName."\n\n");

# Build the oid lists and varbind arrays
my (@dataList, @errorList, @staticList, @rowData);
my ($sleepTime, $dataVals, $errorVals, $runTime);
my ($clientCurConns, $clientTotConns, $serverCurConns, $serverTotConns);
my ($cpuUsed, $cpuTicks, $cpuUtil, $cpuPercent, $memUsed);
my ($timeSpent, $pollRTT, $col, $row, $numRows);
my ($workbook, $summary, $raw_data, $charts, $rowTime, $rowCPU);
my ($cBytesIn, $cBytesOut, $sBytesIn, $sBytesOut, $cPktsIn, $cPktsOut);
my ($ccPktsIn, $ccPktsOut);
my (%formats, %xlsData);

my %staticOids  = &get_static_oids();
my %dataOids    = &get_f5_oids();
my %errorOids   = &get_err_oids();
my %oldData     = ('ssCpuRawUser'   => 0,
                   'ssCpuRawNice'   => 0,
                   'ssCpuRawSystem' => 0,
                   'ssCpuRawIdle'   => 0,
                   'cBytesIn'       => 0,
                   'cBytesOut'      => 0,
                   'sBytesIn'       => 0,
                   'sBytesOut'      => 0,
                  );
my @summaryHdrs = ('RunTime', 'cycleTime', 'CPU', 'Memory', 'Client bitsIn/s', 
                   'Client bitsOut/s', 'Server bitsIn/s', 'Server bitsOut/s', 
                   'Client pktsIn/s', 'Client pktsOut/s', 'Server pktsIn/s', 'Server pktsOut/s',
                   'Client Conn/s', 'Server Conn/s',
                  );
my @rawdataHdrs = ('RunTime', 'CPU', 'Memory', 'Client bytesIn', 'Client bytesOut', 
                   'Client pktsIn', 'Client pktsOut', 'Server btyesIn', 'Server bytesOut', 
                   'Server pktsIn', 'Server pktsOut', 'Client curConns', 'Client totConns', 
                   'Server curConns', 'Server totConns',
                  );

while (my ($key, $value) = each(%staticOids)) { push(@staticList, $value); }
while (my ($key, $value) = each(%dataOids))   { push(@dataList, $value); }
while (my ($key, $value) = each(%errorOids))  { push(@errorList, $value); }

my ($session, $error) = Net::SNMP->session(
  -hostname     => $host,
  -community    => $comm,
  -version      => $snmpVer,
  -maxmsgsize   => 8192,
  -nonblocking  => 0,
);
die($error."\n") if ($error);


# Get the static datapoints and print them to STDOUT
my $result = $session->get_request( -varbindlist  => \@staticList);
while (my ($k, $v) = each(%staticOids)) { print $k.": ".$result->{$v}."\n"; }

# determine if logging is required and create the output files
if ($DATAOUT) {
  $DEBUG && print "Creating workbook...";
  ($workbook, $raw_data, $summary, $charts, %formats) = 
      &mk_perf_xls($xlsName, \@rawdataHdrs, \@summaryHdrs);
}


##
## Begin Main
##

# loop until start-of-test is detected
&detect_test($session, \%dataOids) unless $BYPASS;

# start active polling
$pollTimer{'testStart'} = Time::HiRes::time();
while ($elapsed <= $testLen) {
  
  $pollTimer{'start'} = Time::HiRes::time();

  # get current statistics from DUT
  $dataVals = $session->get_request( -varbindlist  => \@dataList);
  die($session->error."\n") if (!defined($dataVals));
  $pollTimer{'pollend'} = Time::HiRes::time();

  # Before any real processing, remove any non-numeric values (i.e. 'noSuchInstance')
  for my $n (keys(%dataOids)) {
    if ($dataVals->{$dataOids{$n}} =~ /\D+/) {
      $xlsData{$n} = 0;
    }
    else {
      $xlsData{$n} = $dataVals->{$dataOids{$n}};
    }
  }

  # CPU and Memory utilization
  $cpuTicks   = ($dataVals->{$dataOids{'ssCpuRawUser'}}   - $oldData{'ssCpuRawUser'}) +
                ($dataVals->{$dataOids{'ssCpuRawNice'}}   - $oldData{'ssCpuRawNice'}) + 
                ($dataVals->{$dataOids{'ssCpuRawSystem'}} - $oldData{'ssCpuRawSystem'}) + 
                ($dataVals->{$dataOids{'ssCpuRawIdle'}}   - $oldData{'ssCpuRawIdle'});
  $cpuUsed    = $cpuTicks - ($dataVals->{$dataOids{'ssCpuRawIdle'}} - $oldData{'ssCpuRawIdle'});
  $cpuUtil    = (($cpuUsed / $cpuTicks) * 100);
  $cpuPercent = sprintf("%.2f", $cpuUtil);
  $memUsed    = $dataVals->{$dataOids{'tmmTotalMemoryUsed'}};
  my $hMem    = sprintf("%d", $memUsed / MB);

  # client and server currnet connections
  $clientCurConns = $dataVals->{$dataOids{'sysStatClientCurConns'}};
  $serverCurConns = $dataVals->{$dataOids{'sysStatServerCurConns'}};

  # If requested, write the output file.
  if ($DATAOUT) {
    $row++;
    $raw_data->write($row, 0, $runTime, $formats{'decimal4'});
    $raw_data->write($row, 1, $cpuPercent, $formats{'decimal2'});

    $raw_data->write( $row, 
                      2, 
                      [$memUsed,
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientBytesIn'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientBytesOut'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientPktsIn'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientPktsOut'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerBytesIn'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerBytesOut'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerPktsIn'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerPktsOut'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientCurConns'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientTotConns'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerCurConns'}}),
                      sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerTotConns'}})],
                     $formats{'standard'});
    # SIGINT gracefully closes spreadsheet and exits
    # defined in the loop to allow access to $rows
    #$SIG{INT} = &exit_now($workbook, $summary, \%formats, $row);
  }

  if ($VERBOSE) {
    # pre-format some vars
    $cBytesIn   = sprintf("%.0f", ($dataVals->{$dataOids{'sysStatClientBytesIn'}} - 
                            $oldData{'cBytesIn'}) / $cycleTime);
    $cBytesOut  = sprintf("%.0f", ($dataVals->{$dataOids{'sysStatClientBytesOut'}} -
                            $oldData{'cBytesOut'}) / $cycleTime);
    $sBytesIn   = sprintf("%.0f", ($dataVals->{$dataOids{'sysStatServerBytesIn'}} -
                            $oldData{'sBytesIn'}) / $cycleTime);
    $sBytesOut  = sprintf("%.0f", ($dataVals->{$dataOids{'sysStatServerBytesOut'}} -
                            $oldData{'sBytesOut'}) / $cycleTime);

    if ($elapsed > 0) {
      $cPktsIn    = sprintf("%.0f", ($dataVals->{$dataOids{'sysStatClientPktsIn'}} -
                               $oldData{'cPktsIn'}) / $cycleTime);
      $cPktsOut   = sprintf("%.0f", ($dataVals->{$dataOids{'sysStatClientPktsOut'}} -
                               $oldData{'cPktsOut'}) / $cycleTime);
    }
    else {
      $cPktsIn  = 0;
      $cPktsOut = 0;
    }

    format STDOUT_TOP =
@||||| @>>>>>>> @|||||||| @|||||||| @||||||||| @||||||||| @||||||||| @|||||||||
"CPU", "MemUtil", "C-conns", "S-conns", "cBytesIn", "cBytesOut", "cPktsIn", "cPktsOut"
.

    format =
@##.## @>>>>>MB @>>>>>>>> @>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>>
$cpuUtil, $hMem, $clientCurConns, $serverCurConns, $cBytesIn, $cBytesOut, $cPktsIn, $cPktsOut
.
    write;

  }

  # update 'old' data with the current values to calculate delta next cycle
  $oldData{'ssCpuRawUser'}   = $dataVals->{$dataOids{'ssCpuRawUser'}};
  $oldData{'ssCpuRawNice'}   = $dataVals->{$dataOids{'ssCpuRawNice'}};
  $oldData{'ssCpuRawSystem'} = $dataVals->{$dataOids{'ssCpuRawSystem'}};
  $oldData{'ssCpuRawIdle'}   = $dataVals->{$dataOids{'ssCpuRawIdle'}};
  $oldData{'cBytesIn'}       = $dataVals->{$dataOids{'sysStatClientBytesIn'}};
  $oldData{'cBytesOut'}      = $dataVals->{$dataOids{'sysStatClientBytesOut'}};
  $oldData{'sBytesIn'}       = $dataVals->{$dataOids{'sysStatServerBytesIn'}};
  $oldData{'sBytesOut'}      = $dataVals->{$dataOids{'sysStatServerBytesOut'}};
  $oldData{'cPktsIn'}        = $dataVals->{$dataOids{'sysStatClientPktsIn'}};
  $oldData{'cPktsOut'}       = $dataVals->{$dataOids{'sysStatClientPktsOut'}};


  # Calculate how much time this polling cycle has required to determine how
  # long we should sleep before beginning the next cycle
  $pollTimer{'end'} = Time::HiRes::time();

  $pollRTT    = $pollTimer{'pollend'} - $pollTimer{'start'};
  $timeSpent  = $pollTimer{'end'} - $pollTimer{'start'};
  $runTime    = $pollTimer{'end'} - $pollTimer{'testStart'};
  $sleepTime  = ($cycleTime*1000000)-$timeSpent;


  $loopcnt++;
  $elapsed += $cycleTime;
#  usleep($cycleTime * 1000000);
  usleep($sleepTime);
} 


if ($DATAOUT) {
  # polling is now complete, time to write the summary formulas 
  &write_summary($summary, \%formats, $row);

  # embed charts
  # TODO: write a sub to embed charts
  # &embed_charts($charts);

  # close the workbook; required for the workbook to be usable.
  &close_xls($workbook);
}



##
## Subs
##

# delay the start of the script until the test is detected through pkts/sec
sub detect_test() {
  my $snmp = shift;
  my $oids = shift;
  my $pkts = 3000;

  print "Waiting for test to begin...";

  while (1) {
    my $r1 = $snmp->get_request($$oids{'sysStatClientPktsIn'});
    sleep(2);
    my $r2 = $snmp->get_request($$oids{'sysStatClientPktsIn'});

    my $delta = $r2->{$$oids{'sysStatClientPktsIn'}}- 
                $r1->{$$oids{'sysStatClientPktsIn'}};
  
    if ($delta > $pkts) {
      print "\nStart of test detected...\n";
      return;
    }
    else {
      print ".";
      sleep(3);
    }
  }
}

# write the formulas in the summary sheet. 
# IN:   $row  - number of data rows in 'raw_data' worksheet
# OUT:  nothing

sub write_summary() {
  my $summary = shift;
  my $formats = shift;
  my $numRows = shift;
  my ($row, $col, $r1, $r2, $cTime, $rowTime, $runDiff, $rowCPU);
  
  # columns in 'raw_data' sheet
  my %r = ('rowtime'      => 'A',
           'rowcpu'       => 'B',
           'memutil'      => 'C',
           'cltBytesIn'   => 'D',
           'cltBytesOut'  => 'E',
           'cltPktsIn'    => 'F',
           'cltPktsOut'   => 'G',
           'svrBytesIn'   => 'H',
           'svrBytesOut'  => 'I',
           'svrPktsIn'    => 'J',
           'svrPktsOut'   => 'K',
           'cltTotConns'  => 'M',
           'svrTotConns'  => 'O',
          );


  for ($row = 1; $row < $numRows; $row++) {
    $r1    = $row+1;
    $r2    = $row+2;

    #$cTime   = 'raw_data!'.$r{'rowtime'}.$r2.'-raw_data!'.$r{'rowtime'}.$r1;
    $cTime   = $r{'rowtime'}.$r2.'-'.$r{'rowtime'}.$r1;

    # splitting these out is required so a different format can be applied to numbers
    $rowTime = '=raw_data!'.$r{'rowtime'}.$r2;
    $runDiff = '='.$cTime;
    $rowCPU  = '=raw_data!'.$r{'rowcpu'}.$r2;

    # @rowData contains formulas required to populate the summary data sheet.
    # In order, they are: memutil, client bits/sec in, client bits/sec out,
    #                     server bits/sec in, server bits/sec out, client conns/sec,
    #                     server conns/sec
    @rowData = (
      '=raw_data!'   .$r{'memutil'}.$r2,
      '=(((raw_data!'.$r{'cltBytesIn'} .$r2.'-raw_data!'.$r{'cltBytesIn'} .$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'cltBytesOut'}.$r2.'-raw_data!'.$r{'cltBytesOut'}.$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'svrBytesIn'} .$r2.'-raw_data!'.$r{'svrBytesIn'} .$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'svrBytesOut'}.$r2.'-raw_data!'.$r{'svrBytesOut'}.$r1.')/('.$cTime.'))*8)',
      '=((raw_data!'.$r{'cltPktsIn'} .$r2.'-raw_data!'.$r{'cltPktsIn'} .$r1.')/('.$cTime.'))',
      '=((raw_data!'.$r{'cltPktsOut'}.$r2.'-raw_data!'.$r{'cltPktsOut'}.$r1.')/('.$cTime.'))',
      '=((raw_data!'.$r{'svrPktsIn'} .$r2.'-raw_data!'.$r{'svrPktsIn'} .$r1.')/('.$cTime.'))',
      '=((raw_data!'.$r{'svrPktsOut'}.$r2.'-raw_data!'.$r{'svrPktsOut'}.$r1.')/('.$cTime.'))',
      '=((raw_data!' .$r{'cltTotConns'}.$r2.'-raw_data!'.$r{'cltTotConns'}.$r1.')/('.$cTime.'))',
      '=((raw_data!' .$r{'svrTotConns'}.$r2.'-raw_data!'.$r{'svrTotConns'}.$r1.')/('.$cTime.'))',
    );

    $DEBUG && print Dumper(\@rowData);
    $summary->write($row, 0, [$rowTime, $runDiff], ${$formats}{'decimal4'});
    $summary->write($row, 2, $rowCPU,   ${$formats}{'decimal2'});
    $summary->write($row, 3, \@rowData, ${$formats}{'standard'});
  }
}

## returns a has containing the data-oids
sub get_f5_oids() {
  my %oidlist = (
      'ssCpuRawUser'            => '.1.3.6.1.4.1.2021.11.50.0',
      'ssCpuRawNice'            => '.1.3.6.1.4.1.2021.11.51.0',
      'ssCpuRawSystem'          => '.1.3.6.1.4.1.2021.11.52.0',
      'ssCpuRawIdle'            => '.1.3.6.1.4.1.2021.11.53.0',
      'tmmTotalMemoryUsed'      => '.1.3.6.1.4.1.3375.2.1.1.2.1.45.0',
      'sysStatClientBytesIn'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.3.0',
      'sysStatClientBytesOut'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.5.0',
      'sysStatClientPktsIn'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.2.0',
      'sysStatClientPktsOut'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.4.0',
      'sysStatClientTotConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.7.0',
      'sysStatClientCurConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.8.0',
      'sysStatServerBytesIn'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.10.0',
      'sysStatServerBytesOut'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.12.0',
      'sysStatServerPktsIn'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.9.0',
      'sysStatServerPktsOut'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.11.0',
      'sysStatServerTotConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.14.0',
      'sysStatServerCurConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.15.0',
      'sysIpStatDropped'        => '.1.3.6.1.4.1.3375.2.1.1.2.7.4.0',
                );

  return(%oidlist);
}

# returns a hash containing oids that will be polled only once
sub get_static_oids() {
  my %oidlist = ( 'ltmVersion'   => '.1.3.6.1.4.1.3375.2.1.4.2.0',
                  'platform'     => '.1.3.6.1.4.1.3375.2.1.3.3.1.0',
                  'cpuCount'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.38.0',
                  'totalMemory'  => '.1.3.6.1.4.1.3375.2.1.1.2.1.44.0',
                );

  return(%oidlist);
}

# returns a has containing oids that track errors
sub get_err_oids() {
  my %oidlist = (
      'incomingPktErrors'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.47.0',
      'outgoingPktErrors'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.48.0',
      'IPDroppedPkts'       => '.1.3.6.1.4.1.3375.2.1.1.2.7.4.0',
      'vipNonSynDeny'       => '.1.3.6.1.4.1.3375.2.1.1.2.21.20.0',
      'cmpConnRedirected'   => '.1.3.6.1.4.1.3375.2.1.1.2.21.23.0',
      'connMemErrors'       => '.1.3.6.1.4.1.3375.2.1.1.2.21.24.0',
  );

  return(%oidlist);
}


sub mk_perf_xls() {
  my $fname   = shift;
  my $rawHdrs = shift;
  my $sumHdrs = shift;
  my %hdrfmts;

  ## create Excel workbook
  my $workbook = Spreadsheet::WriteExcel->new($fname);
  $workbook->compatibility_mode();  # stops the 'data may have been lost' error

  # define formatting
  $hdrfmts{'headers'}  = $workbook->add_format(align => 'center', bold => 1, bottom => 1);
  $hdrfmts{'standard'} = $workbook->add_format(align => 'center', num_format => '#,##0');
  $hdrfmts{'decimal2'} = $workbook->add_format(align => 'center', num_format => '0.00');
  $hdrfmts{'decimal4'} = $workbook->add_format(align => 'center', num_format => '0.0000');

  # create worksheets
  # the 'charts' worksheet will contain graphs using data from the 'summary' sheet.
  my $charts = $workbook->add_worksheet('charts');
  $charts->set_zoom(80);
  #$charts->activate();

  # the 'summary' worksheet contains summarized data from the 'raw_data' worksheet.
  my $summary = $workbook->add_worksheet('summary');
  $summary->set_zoom(80);
  $summary->set_column('A:A', 10);
  $summary->set_column('B:B', 11);
  $summary->set_column('C:C', 8);
  $summary->set_column('D:D', 13);
  $summary->set_column('E:N', 18);
  $summary->activate();

  # contains the raw data retrieved with SNMP
  my $rawdata = $workbook->add_worksheet('raw_data');
  $rawdata->set_zoom(80);
  $rawdata->set_column('A:B', 9);
  $rawdata->set_column('C:H', 15);
  $rawdata->set_column('I:Z', 16);

  $summary->write(0, 0, $sumHdrs, $hdrfmts{'headers'});
  $rawdata->write(0, 0, $rawHdrs, $hdrfmts{'headers'});

  return($workbook, $rawdata, $summary, $charts, %hdrfmts);
}

# Close the spreadsheet -- REQUIRED
sub close_xls() {
  my $xls = shift;

  $xls->close();

  return(1);
}

# exits the program immediately
sub exit_now() {
  my $xls     = shift;
  my $summary = shift;
  my $formats = shift;
  my $numRows = shift;

  &write_summary($summary, $formats, $numRows);
  &close_xls($xls);
  exit(5);
}



# print script usage and exit with the supplied status
sub usage() {
  my $code = shift;

  print <<END;
  USAGE:  $0 -d <host> -l <total test length> -o <output file>
          $0 -h

  -d      IP or hostname to query (REQUIRED)
  -l      Full Test duration             (default: 140 seconds)
  -i      Seconds between polling cycles (default: 4 seconds)
  -o      Output filename                (default: /dev/null)
  -v      Verbose output (print stats)
  -B      Bypass start-of-test detection and start polling immediately
  -h      Print usage and exit

END

  exit($code);
}
