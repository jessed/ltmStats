#! /usr/bin/perl

## Required libraries
#
use warnings;
use strict;
use Getopt::Std;
use Net::SNMP qw(:snmp);
use Time::HiRes qw(usleep time clock);
use Spreadsheet::WriteExcel;
use Data::Dumper;

$!++;  # No buffer for STDOUT
## retrieve and process CLI paramters
#
our (%opts, $DATAOUT, $BYPASS, $DEBUG, $VERBOSE, $CUSTOMER, $TESTNAME, $COMMENTS);
getopts('d:l:o:C:T:m:c:s:i:BDvh', \%opts);


# print usage and exit
&usage(0) if $opts{'h'};

if (!$opts{'d'}) {
  warn("Must provide a hostname or IP address to query\n");
  &usage(1);
}

my $host      = $opts{'d'};                 # snmp host to poll
my $testLen   = $opts{'l'} || 140;          # total duration of test in seconds
my $xlsName   = $opts{'o'} || '/dev/null';  # output file name
my $snmpVer   = $opts{'s'} || 'v2c';        # snmp version
my $comm      = $opts{'c'} || 'public';     # community string    
my $cycleTime = $opts{'i'} || 5;            # polling interval

my $loopcnt   = 25;                         # controls frequency of column headers

if ($opts{'o'}) { $DATAOUT    = 1; }
if ($opts{'B'}) { $BYPASS     = 1; }
if ($opts{'D'}) { $DEBUG      = 1; }
if ($opts{'v'}) { $VERBOSE    = 1; }
if ($opts{'C'}) { $CUSTOMER   = $opts{'C'}; }
if ($opts{'T'}) { $TESTNAME   = $opts{'T'}; }
if ($opts{'m'}) { $COMMENTS   = $opts{'m'}; }

## normal vars
#
my $elapsed   = 0;       # total time test has been running
my %pollTimer = ();      # tracks the amount on time required for each poll operation


if ($DEBUG) {
  print Dumper(\%opts);
  print "DATAOUT:  ".$DATAOUT. "\n";
  print "BYPASS:   ".$BYPASS.  "\n";
  print "DEBUG:    ".$DEBUG.   "\n";
  print "VERBOSE:  ".$VERBOSE. "\n";
  print "CUSTOMER: ".$CUSTOMER."\n";
  print "TESTNAME: ".$TESTNAME."\n";
  print "COMMENTS: ".$COMMENTS."\n";
}

# additional constants
use constant MB       => 1024*1024;

##
## Initialization and environment check
##

$VERBOSE && print("Host: ".$host."\nDuration: ".$testLen." seconds\nFile: ".$xlsName."\n\n");

# Build the oid lists and varbind arrays
my (@dataList, @errorList, @staticList, @rowData);
my ($sleepTime, $dataVals, $errorVals, $testStart, $runTime);
my ($clientCurConns, $clientTotConns, $serverCurConns, $serverTotConns);
my ($cpuUsed, $cpuTicks, $cpuUtil, $cpuPercent, $memUsed);
my ($timeSpent, $pollRTT, $col, $row, $numRows);
my ($workbook, $summary, $raw_data, $rowTime, $rowCPU);
my ($clientBytesIn, $clientBytesOut, $serverBytesIn, $serverBytesOut);
my ($rawBytesIn, $rawBytesOut, $optBytesIn, $optBytesOut);
my (%formats, %xlsData);

my %staticOids  = &get_static_oids();
my %dataOids    = &get_f5_oids();
my %errorOids   = &get_err_oids();
my %oldData     = ('ssCpuRawUser'   => 0,
                   'ssCpuRawNice'   => 0,
                   'ssCpuRawSystem' => 0,
                   'ssCpuRawIdle'   => 0,
                   'clientBytesIn'  => 0,
                   'clientBytesOut' => 0,
                   'serverBytesIn'  => 0,
                   'serverBytesOut' => 0,
                   'rawBytesIn'     => 0,
                   'optBytesOut'    => 0,
                   'optBytesIn'     => 0,
                   'rawBytesOut'    => 0,
                  );
my @summaryHdrs = ('RunTime', 'CPU', 'Memory', 'Client bitsIn/sec', 
                   'Client bitsOut/sec', 'Server bitsIn/sec', 'Server bitsOut/sec', 
                  );
my @rawdataHdrs = ('RunTime', 'CPU', 'Memory', 'Client bytesIn', 'Client bytesOut', 
                   'Client pktsIn', 'Client pktsOut', 'Server btyesIn', 'Server bytesOut', 
                   'Server pktsIn', 'Server pktsOut', 'Client curConns', 'Client totConns', 
                   'Server curConns', 'Server totConns', 'Raw bytesIn', 'Opt bytesOut',
                   'Opt bytesIn', 'Raw bytesOut',
                  );
my @dataNames   = ('sysStatClientBytesIn', 'sysStatClientBytesOut', 'sysStatClientPktsIn', 
                   'sysStatClientPktsOut', 'sysStatServerBytesIn', 'sysStatServerBytesOut', 
                   'sysStatServerPktsIn', 'sysStatServerPktsOut', 'sysStatClientCurConns',
                   'sysStatClientTotConns', 'sysStatServerCurConns', 'sysStatServerTotConns', 
                   'iSessionCompRawBytesIn', 'iSessionCompOptBytesOut', 'iSessionCompOptBytesIn',
                   'iSessionCompRawBytesOut',
                  );

while (my ($key, $value) = each(%staticOids)) { push(@staticList, $value); }
while (my ($key, $value) = each(%dataOids))   { push(@dataList, $value); }
while (my ($key, $value) = each(%errorOids))  { push(@errorList, $value); }

my ($session, $error) = Net::SNMP->session(
  -hostname     => $host,
  -community    => $comm,
  -version      => $snmpVer,
  -maxmsgsize   => 8192,
  -nonblocking  => 0,
);
die($error."\n") if ($error);


# Get the static datapoints and print them to STDOUT
my $result = $session->get_request( -varbindlist  => \@staticList);
while (my ($k, $v) = each(%staticOids)) { print $k.": ".$result->{$v}."\n"; }

# determine if logging is required and create the output files
if ($DATAOUT) {
  $DEBUG && print "Creating workbook...";
  ($workbook, $raw_data, $summary, %formats) = &mk_perf_xls($xlsName, \@rawdataHdrs, \@summaryHdrs);
}


##
## Begin Main
##

# loop until start-of-test is detected
&detect_test($session, \%dataOids) unless $BYPASS;

$testStart = Time::HiRes::time(); # start tracking time

# set up some vars to hold some data from the previous loop
# start active polling
while ($elapsed <= $testLen) {
  $pollTimer{'start'} = Time::HiRes::time();

  # get current statistics from DUT
  $dataVals = $session->get_request( -varbindlist  => \@dataList);
  die($session->error."\n") if (!defined($dataVals));
  $pollTimer{'pollend'} = Time::HiRes::time();

  # Before any real processing, remove any non-numeric values (i.e. 'noSuchInstance')
  for my $n (keys(%dataOids)) {
    if ($dataVals->{$dataOids{$n}} =~ /\D+/) {
      $xlsData{$n} = 0;
    }
    else {
      $xlsData{$n} = $dataVals->{$dataOids{$n}};
    }
  }

  # CPU and Memory utilization
  $cpuTicks   = ($dataVals->{$dataOids{'ssCpuRawUser'}}   - $oldData{'ssCpuRawUser'}) +
                ($dataVals->{$dataOids{'ssCpuRawNice'}}   - $oldData{'ssCpuRawNice'}) + 
                ($dataVals->{$dataOids{'ssCpuRawSystem'}} - $oldData{'ssCpuRawSystem'}) + 
                ($dataVals->{$dataOids{'ssCpuRawIdle'}}   - $oldData{'ssCpuRawIdle'});
  $cpuUsed    = $cpuTicks - ($dataVals->{$dataOids{'ssCpuRawIdle'}} - $oldData{'ssCpuRawIdle'});
  $cpuUtil    = (($cpuUsed / $cpuTicks) * 100);
  $cpuPercent = sprintf("%.2f", $cpuUtil);
  $memUsed    = $dataVals->{$dataOids{'tmmTotalMemoryUsed'}};

  # client and server currnet connections
  $clientCurConns = $dataVals->{$dataOids{'sysStatClientCurConns'}};
  $serverCurConns = $dataVals->{$dataOids{'sysStatServerCurConns'}};

  # If requested, write the output file.
  if ($DATAOUT) {
    # Write the snmp results to teh spreadsheet
    $row++;
    $raw_data->write($row, 0, $runTime, $formats{'decimal4'});
    $raw_data->write($row, 1, $cpuPercent, $formats{'decimal2'});

    $raw_data->write( $row, 
                      2, 
                      [$memUsed,
                      sprintf("%.0f", $xlsData{'sysStatClientBytesIn'}),
                      sprintf("%.0f", $xlsData{'sysStatClientBytesOut'}),
                      sprintf("%.0f", $xlsData{'sysStatClientPktsIn'}),
                      sprintf("%.0f", $xlsData{'sysStatClientPktsOut'}),
                      sprintf("%.0f", $xlsData{'sysStatServerBytesIn'}),
                      sprintf("%.0f", $xlsData{'sysStatServerBytesOut'}),
                      sprintf("%.0f", $xlsData{'sysStatServerPktsIn'}),
                      sprintf("%.0f", $xlsData{'sysStatServerPktsOut'}),
                      sprintf("%.0f", $xlsData{'sysStatClientCurConns'}),
                      sprintf("%.0f", $xlsData{'sysStatClientTotConns'}),
                      sprintf("%.0f", $xlsData{'sysStatServerCurConns'}),
                      sprintf("%.0f", $xlsData{'sysStatServerTotConns'}),
                      sprintf("%.0f", $xlsData{'iSessionCompRawBytesIn'}),
                      sprintf("%.0f", $xlsData{'iSessionCompOptBytesOut'}),
                      sprintf("%.0f", $xlsData{'iSessionCompOptBytesIn'}),
                      sprintf("%.0f", $xlsData{'iSessionCompRawBytesOut'}),
                      ],
                     $formats{'standard'});
  }

  # print stats to STDOUT if requested
  if ($VERBOSE) {
    $clientBytesIn  = sprintf("%.0f", ($xlsData{'sysStatClientBytesIn'} - 
                                $oldData{'clientBytesIn'}) / $cycleTime);
    $clientBytesOut = sprintf("%.0f", ($xlsData{'sysStatClientBytesOut'} - 
                                $oldData{'clientBytesOut'}) / $cycleTime);

    $serverBytesIn  = sprintf("%.0f", ($xlsData{'sysStatServerBytesIn'} - 
                                $oldData{'serverBytesIn'}) / $cycleTime);
    $serverBytesOut = sprintf("%.0f", ($xlsData{'sysStatServerBytesOut'} - 
                                $oldData{'serverBytesOut'}) / $cycleTime);

    $rawBytesIn  = sprintf("%.0f", ($xlsData{'iSessionCompRawBytesIn'} - 
                                $oldData{'rawBytesIn'}) / $cycleTime);
    $optBytesOut = sprintf("%.0f", ($xlsData{'iSessionCompOptBytesOut'} - 
                                $oldData{'optBytesOut'}) / $cycleTime);

    $optBytesIn  = sprintf("%.0f", ($xlsData{'iSessionCompOptBytesIn'} -
                                $oldData{'optBytesIn'}) / $cycleTime);
    $rawBytesOut = sprintf("%.0f", ($xlsData{'iSessionCompRawBytesOut'} -
                                $oldData{'rawBytesOut'}) / $cycleTime);

    my $compPercentOut = 0;
    my $compPercentIn  = 0;

    if ( $rawBytesIn != 0 && $rawBytesOut != 0) {
      $compPercentOut = (($rawBytesIn - $optBytesOut) / $rawBytesIn) * 100;
      $compPercentIn  = (($rawBytesOut - $optBytesIn) / $rawBytesOut) * 100;
    }


    format STDOUT_TOP =
@>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>> @>>>>>
"cBytesIn", "rBytesIn", "sBytesOut", "oBytesOut", "sBytesIn", "oBytesIn", "cBytesOut", "rBytesOut", "Req%", "Res%"
.

    format =
@>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @>>>>>>>>> @##.##% @##.##%
$clientBytesIn, $rawBytesIn, $serverBytesOut, $optBytesOut, $serverBytesIn, $optBytesIn, $clientBytesOut, $rawBytesOut, $compPercentOut, $compPercentIn
.
    write;

    $oldData{'clientBytesIn'}  = $xlsData{'sysStatClientBytesIn'};
    $oldData{'clientBytesOut'} = $xlsData{'sysStatClientBytesOut'};
    $oldData{'serverBytesIn'}  = $xlsData{'sysStatServerBytesIn'};
    $oldData{'serverBytesOut'} = $xlsData{'sysStatServerBytesOut'};
    $oldData{'rawBytesIn'}     = $xlsData{'iSessionCompRawBytesIn'};
    $oldData{'optBytesOut'}    = $xlsData{'iSessionCompOptBytesOut'};
    $oldData{'optBytesIn'}     = $xlsData{'iSessionCompOptBytesIn'};
    $oldData{'rawBytesOut'}    = $xlsData{'iSessionCompRawBytesOut'};
  }

  # update 'old' data with the current values to calculate delta next cycle
  $oldData{'ssCpuRawUser'}   = $xlsData{'ssCpuRawUser'};
  $oldData{'ssCpuRawNice'}   = $xlsData{'ssCpuRawNice'};
  $oldData{'ssCpuRawSystem'} = $xlsData{'ssCpuRawSystem'};
  $oldData{'ssCpuRawIdle'}   = $xlsData{'ssCpuRawIdle'};




  # Calculate how much time this polling cycle has required to determine how
  # long we should sleep before beginning the next cycle
  $pollTimer{'end'} = Time::HiRes::time();

  $pollRTT    = $pollTimer{'pollend'} - $pollTimer{'start'};
  $timeSpent  = $pollTimer{'end'} - $pollTimer{'start'};
  $runTime    = $pollTimer{'end'} - $testStart;
  $sleepTime  = $cycleTime-$timeSpent;

  $loopcnt++;
  $elapsed += $cycleTime;
  usleep($cycleTime * 1000000);
} 


if ($DATAOUT) {
  # polling is now complete, time to write the summary formulas 
  &write_summary($summary, \%formats, $row);

  # close the workbook; required for the workbook to be usable.
  # &close_xls($workbook);
  $workbook->close();
}



##
## Subs
##

# delay the start of the script until the test is detected through pkts/sec
sub detect_test() {
  my $snmp = shift;
  my $oids = shift;
  my $pkts = 3000;

  print "Waiting for test to begin...";

  while (1) {
    my $r1 = $snmp->get_request($$oids{'sysStatClientPktsIn'});
    sleep(2);
    my $r2 = $snmp->get_request($$oids{'sysStatClientPktsIn'});

    my $delta = $r2->{$$oids{'sysStatClientPktsIn'}}- 
                $r1->{$$oids{'sysStatClientPktsIn'}};
  
    if ($delta > $pkts) {
      print "\nStart of test detected...\n";
      return;
    }
    else {
      print ".";
      sleep(3);
    }
  }
}

# write the formulas in the summary sheet. 
# IN:   $row  - number of data rows in 'raw_data' worksheet
# OUT:  nothing

sub write_summary() {
  my $summary = shift;
  my $formats = shift;
  my $numRows = shift;
  my ($row, $col, $r1, $r2, $cTime, $rowTime, $runDiff, $rowCPU);
  
  # columns in 'raw_data' sheet
  my %r = ('rowtime'      => 'A',
           'rowcpu'       => 'B',
           'memutil'      => 'C',
           'cltBytesIn'   => 'D',
           'cltBytesOut'  => 'E',
           'svrBytesIn'   => 'H',
           'svrBytesOut'  => 'I',
           'cltTotConns'  => 'M',
           'svrTotConns'  => 'O',
          );


  for ($row = 0; $row < $numRows; $row++) {
    $r1    = $row+1;
    $r2    = $row+2;

    $cTime   = 'raw_data!'.$r{'rowtime'}.$r2.'-raw_data!'.$r{'rowtime'}.$r1;

    # splitting these out is required so a different format can be applied to numbers
    $rowTime = '=raw_data!'.$r{'rowtime'}.$r2;
    $runDiff = '='.$cTime;
    $rowCPU  = '=raw_data!'.$r{'rowcpu'}.$r2;

    # @rowData contains formulas required to populate the summary data sheet.
    # In order, they are: memutil, client bits/sec in, client bits/sec out,
    #                     server bits/sec in, server bits/sec out, client conns/sec,
    #                     server conns/sec
    @rowData = (
      '=raw_data!'   .$r{'memutil'}.$r2,
      '=(((raw_data!'.$r{'cltBytesIn'} .$r2.'-raw_data!'.$r{'cltBytesIn'} .$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'cltBytesOut'}.$r2.'-raw_data!'.$r{'cltBytesOut'}.$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'svrBytesIn'} .$r2.'-raw_data!'.$r{'svrBytesIn'} .$r1.')/('.$cTime.'))*8)',
      '=(((raw_data!'.$r{'svrBytesOut'}.$r2.'-raw_data!'.$r{'svrBytesOut'}.$r1.')/('.$cTime.'))*8)',
      #'=((raw_data!' .$r{'cltTotConns'}.$r2.'-raw_data!'.$r{'cltTotConns'}.$r1.')/('.$cTime.'))',
      #'=((raw_data!' .$r{'svrTotConns'}.$r2.'-raw_data!'.$r{'svrTotConns'}.$r1.')/('.$cTime.'))',
    );

    $DEBUG && print Dumper(\@rowData);
    #$summary->write($row, 0, [$rowTime, $runDiff], ${$formats}{'decimal4'});
    $summary->write($row, 0, $rowTime,  ${$formats}{'standard'});
    $summary->write($row, 1, $rowCPU,   ${$formats}{'decimal2'});
    $summary->write($row, 2, \@rowData, ${$formats}{'standard'});
  }
}


## returns a has containing the data-oids
sub get_f5_oids() {
  my %oidlist = (
      'ssCpuRawUser'            => '.1.3.6.1.4.1.2021.11.50.0',
      'ssCpuRawNice'            => '.1.3.6.1.4.1.2021.11.51.0',
      'ssCpuRawSystem'          => '.1.3.6.1.4.1.2021.11.52.0',
      'ssCpuRawIdle'            => '.1.3.6.1.4.1.2021.11.53.0',
      'tmmTotalMemoryUsed'      => '.1.3.6.1.4.1.3375.2.1.1.2.1.45.0',
      'sysStatClientBytesIn'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.3.0',
      'sysStatClientBytesOut'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.5.0',
      'sysStatClientPktsIn'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.2.0',
      'sysStatClientPktsOut'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.4.0',
      'sysStatClientTotConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.7.0',
      'sysStatClientCurConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.8.0',
      'sysStatServerBytesIn'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.10.0',
      'sysStatServerBytesOut'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.12.0',
      'sysStatServerPktsIn'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.9.0',
      'sysStatServerPktsOut'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.11.0',
      'sysStatServerTotConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.14.0',
      'sysStatServerCurConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.15.0',
      'sysIpStatDropped'        => '.1.3.6.1.4.1.3375.2.1.1.2.7.4.0',
      'iSessionCompRawBytesIn'  => '.1.3.6.1.4.1.3375.2.2.6.21.2.3.1.3.24.116.114.97.110.115.112.111.114.116.95.102.111.114.119.97.114.100.105.110.103.95.116.99.112',
      'iSessionCompOptBytesOut' => '.1.3.6.1.4.1.3375.2.2.6.21.2.3.1.4.24.116.114.97.110.115.112.111.114.116.95.102.111.114.119.97.114.100.105.110.103.95.116.99.112',
      'iSessionCompOptBytesIn'  => '.1.3.6.1.4.1.3375.2.2.6.21.2.3.1.5.24.116.114.97.110.115.112.111.114.116.95.102.111.114.119.97.114.100.105.110.103.95.116.99.112',
      'iSessionCompRawBytesOut' => '.1.3.6.1.4.1.3375.2.2.6.21.2.3.1.6.24.116.114.97.110.115.112.111.114.116.95.102.111.114.119.97.114.100.105.110.103.95.116.99.112',
                );

  return(%oidlist);
}

# returns a hash containing oids that will be polled only once
sub get_static_oids() {
  my %oidlist = ( 'ltmVersion'   => '.1.3.6.1.4.1.3375.2.1.4.2.0',
                  'platform'     => '.1.3.6.1.4.1.3375.2.1.3.3.1.0',
                  'cpuCount'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.38.0',
                  'totalMemory'  => '.1.3.6.1.4.1.3375.2.1.1.2.1.44.0',
                );

  return(%oidlist);
}

# returns a has containing oids that track errors
sub get_err_oids() {
  my %oidlist = (
      'incomingPktErrors'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.47.0',
      'outgoingPktErrors'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.48.0',
      'IPDroppedPkts'       => '.1.3.6.1.4.1.3375.2.1.1.2.7.4.0',
      'vipNonSynDeny'       => '.1.3.6.1.4.1.3375.2.1.1.2.21.20.0',
      'cmpConnRedirected'   => '.1.3.6.1.4.1.3375.2.1.1.2.21.23.0',
      'connMemErrors'       => '.1.3.6.1.4.1.3375.2.1.1.2.21.24.0',
  );

  return(%oidlist);
}


sub mk_perf_xls() {
  my $fname   = shift;
  my $rawHdrs = shift;
  my $sumHdrs = shift;
  my $r = 0;
  my $c = 0;
  my %hdrfmts;

  ## create Excel workbook
  my $workbook = Spreadsheet::WriteExcel->new($fname);

  # define formatting
  $hdrfmts{'headers'}  = $workbook->add_format(align => 'center', bold => 1, bottom => 1);
  $hdrfmts{'standard'} = $workbook->add_format(align => 'center', num_format => '#,##0');
  $hdrfmts{'decimal2'} = $workbook->add_format(align => 'center', num_format => '0.00');
  $hdrfmts{'decimal4'} = $workbook->add_format(align => 'center', num_format => '0.0000');

  # create worksheets
  my $summary = $workbook->add_worksheet('summary');
  $summary->set_column('A:C', 9);
  $summary->set_column('D:M', 17);
  $summary->activate();

  my $rawdata = $workbook->add_worksheet('raw_data');
  $rawdata->set_column('A:B', 9);
  $rawdata->set_column('C:Z', 15);

  $summary->write($r, $c, $sumHdrs, $hdrfmts{'headers'});
  $rawdata->write($r, $c, $rawHdrs, $hdrfmts{'headers'});

  return($workbook, $rawdata, $summary, %hdrfmts);
}

# Close the spreadsheet -- REQUIRED
sub close_xls() {
  my $xls = shift;

  $xls->close();

  return(1);
}


# print script usage and exit with the supplied status
sub usage() {
  my $code = shift;

  print <<END;
  USAGE:  $0 -d <host> -l <total test length> -o <output file>
          $0 -h

  -d      IP or hostname to query (REQUIRED)
  -l      Full Test duration             (default: 140 seconds)
  -i      Seconds between polling cycles (default: 4 seconds)
  -o      Output filename                (default: /dev/null)
  -h      Print usage and exit

END

  exit($code);
}
