#! /bin/bash

# will loop ltmStats.xlsx until $count is reached or told to stop
# This script will bypass the normal test monitoring and start recording stats
# immediately.


prog="$HOME/bin/ltmStats.pl"    # replace this with the correct, working path
limit=72                        # number of times to run ltmStats

dut=$1                          # replace with the hostname or IP of the DUT
duration=3600                   # number of seconds ltmStats should run
prefix=$(date +%F--%H_%M)


for (( count=0; $count < $limit; count++)); do
  $prog -vd $dut -l $duration -o $prefix--$count -B
done

