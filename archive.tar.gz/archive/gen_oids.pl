#! /usr/bin/perl -w
use strict;

my @SERVER_STATS = qw(ServerPktsIn ServerPktsOut ServerBytesIn ServerBytesOut ServerTotConns ServerCurConns ServerMaxConns);

my %POOLS = (
		cmcc_pool_1 => [qw(10.22.10.2:80 10.22.10.3:80)],
	);

my %POOL_TO_OID = (
		cmcc_pool_1 => "11.99.109.99.99.95.112.111.111.108.95.49",
);

my @GLOBAL_STATS = qw(HttpStatResp2xxCnt HttpStatResp3xxCnt HttpStatResp4xxCnt HttpStatResp5xxCnt HttpStatNumberReqs HttpStatGetReqs HttpStatPostReqs HttpStatV9Reqs HttpStatV10Reqs HttpStatV11Reqs HttpStatV9Resp HttpStatV10Resp HttpStatV11Resp HttpStatMaxKeepaliveReq HttpStatRespBucket1k HttpStatRespBucket4k HttpStatRespBucket16k HttpStatRespBucket32k HttpStatPrecompressBytes HttpStatPostcompressBytes HttpStatNullCompressBytes HttpStatHtmlPrecompressBytes HttpStatHtmlPostcompressBytes HttpStatCssPrecompressBytes HttpStatCssPostcompressBytes HttpStatJsPrecompressBytes HttpStatJsPostcompressBytes HttpStatXmlPrecompressBytes HttpStatXmlPostcompressBytes HttpStatPlainPrecompressBytes HttpStatPlainPostcompressBytes HttpStatOctetPrecompressBytes HttpStatOctetPostcompressBytes HttpStatImagePrecompressBytes HttpStatImagePostcompressBytes HttpStatVideoPrecompressBytes HttpStatVideoPostcompressBytes HttpStatAudioPrecompressBytes HttpStatAudioPostcompressBytes HttpStatOtherPrecompressBytes HttpStatOtherPostcompressBytes HttpStatRamcacheHits HttpStatRamcacheMisses HttpStatRamcacheMissesAll HttpStatRamcacheHitBytes HttpStatRamcacheMissBytes HttpStatRamcacheMissBytesAll HttpStatRamcacheSize HttpStatRamcacheCount HttpStatRamcacheEvictions HttpStatRespBucket64k StatResetStats StatClientPktsIn StatClientBytesIn StatClientPktsOut StatClientBytesOut StatClientMaxConns StatClientTotConns StatClientCurConns StatServerPktsIn StatServerBytesIn StatServerPktsOut StatServerBytesOut StatServerMaxConns StatServerTotConns StatServerCurConns StatVirtualServerNonSynDeny StatNoHandlerDeny StatTmTotalCycles StatTmIdleCycles StatTmSleepCycles StatMemoryTotal StatMemoryUsed StatDroppedPackets StatIncomingPacketErrors StatOutgoingPacketErrors StatHttpRequests TcpStatOpen TcpStatAccepts TcpStatAcceptfails TcpStatConnects TcpStatConnfails TcpStatExpires TcpStatAbandons TcpStatRxrst TcpStatRxbadsum TcpStatRxbadseg TcpStatRxooseg TcpStatRxcookie TcpStatRxbadcookie TcpStatSyncacheover TcpStatTxrexmits SystemUptime);

my @output = ();
my @oids = ();
my $stat;

foreach $stat (@GLOBAL_STATS) {
	push(@oids, "F5-BIGIP-SYSTEM-MIB::sys" . $stat . ".0");
}

foreach my $pool (keys %POOLS) {
	foreach $stat (@SERVER_STATS) {
		push(@oids, "F5-BIGIP-LOCAL-MIB::ltmPoolStat" . $stat . '."' . $pool . '"');
	}
}

#	foreach my $member ( @{$POOLS{$pool}} ) {
#		foreach my $stat (@SERVER_STATS) {
#			push(@oids, 'F5-BIGIP-LOCAL-MIB::ltmPoolMemberStat' . $stat . '.' . $POOL_TO_OID{$pool} .
#				'.' . (split(/:/, $member))[0] . '.' . (split(/:/, $member))[1]);
#		}
#	}
#}

my $snmp_cmd = "snmpget";
my @default_args = qw(-v2c -c public 172.27.5.159);
my @args = @default_args;

for (my $i=0; $i <= $#oids; $i++) {
	push(@args, $oids[$i]);
	if (($i > 0 && $i % 128 == 0) ||
	    ($i == $#oids)) {
		system($snmp_cmd, @args);
		@args = @default_args;
	}
}

foreach (@output) {
	print "$_\n";
}
