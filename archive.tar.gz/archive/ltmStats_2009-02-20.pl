#! /usr/bin/perl

## Required libraries
#
use warnings;
use strict;
use Getopt::Std;
use Net::SNMP qw(:snmp);
use Time::HiRes qw(usleep time clock);
use Spreadsheet::WriteExcel;

## retrieve CLI paramters
#
our(%opts);
getopts('d:l:f:h', \%opts);

# if cli syntax was requested
if ($opts{'h'}) {
  &usage();
  exit(0);
}

if (!$opts{'d'}) {
  warn("Must provide a hostname or IP address to query\n");
  &usage();
  exit(1);
}

## Configuration vars
#
my $host      = $opts{'d'};                  # Host to poll
my $testLen   = $opts{'l'} || 140;           # total duration of test in seconds
my $xlsName   = $opts{'f'} || '/dev/null';   # output file name

print("Polling '".$host."' for ".$testLen." seconds and writing output to '".$xlsName."'.\n\n");


## normal vars
#
my $cycleTime = 5;       # seconds between polling cycles
my $elapsed   = 0;       # total time test has been running
my %pollTimer = ();      # tracks the amount on time required for each poll operation
my $snmpVer   = 'v2c';
my $comm      = 'public';

## constants / global vars
#
use constant DATAOUT  => 1;
use constant BYPASS   => 0;
use constant DEBUG    => 1;
use constant MB       => 1024*1024;

# Test and customer information
use constant TESTNAME => '';
use constant AUTHOR   => '';
use constant COMPANY  => '';
use constant COMMENTS => '';




##
## Initialization and environment check
##

# Build the oid lists and varbind arrays
my (@dataList, @errorList, @staticList, @rowData);
my ($sleepTime, $dataVals, $errorVals, $testStart, $runTime);
my ($clientCurConns, $clientTotConns, $serverCurConns, $serverTotConns);
my ($cpuUsed, $cpuTicks, $cpuUtil, $cpuPercent, $memUsed);
my ($timeSpent, $pollRTT, $col, $row, $rawRow);
my ($workbook, $summary, $raw_data, $hdrfmt, $stdfmt, $fmt2dec, $fmt3dec);

my %staticOids  = &get_static_oids();
my %dataOids    = &get_f5_oids();
my %errorOids   = &get_err_oids();
my %oldData     = ('ssCpuRawUser'   => 0,
                   'ssCpuRawNice'   => 0,
                   'ssCpuRawSystem' => 0,
                   'ssCpuRawIdle'   => 0,
                  );
my @summaryHdrs = ('RunTime', 'CPU', 'Memory', 'Client bitsIn/sec', 'Client bitsOut/sec',
                   'Server bitsIn/sec', 'Server bitsOut/sec', 'Client Conns/sec', 
                   'Server Conns/sec',
                  );
my @rawdataHdrs = ('RunTime', 'CPU', 'Memory', 'Client bytesIn', 'Client bytesOut', 
                   'Client pktsIn', 'Client pktsOut', 'Server btyesIn', 'Server bytesOut', 
                   'Server pktsIn', 'Server pktsOut', 'Client curConns', 'Client totConns', 
                   'Server curConns', 'Server totConns',
                  );

while (my ($key, $value) = each(%staticOids)) { push(@staticList, $value); }
while (my ($key, $value) = each(%dataOids))   { push(@dataList, $value); }
while (my ($key, $value) = each(%errorOids))  { push(@errorList, $value); }

my ($session, $error) = Net::SNMP->session(
  -hostname     => $host,
  -community    => $comm,
  -version      => $snmpVer,
  -maxmsgsize   => 8192,
  -nonblocking  => 0,
);
die($error."\n") if ($error);


# Get the static datapoints and print them to STDOUT
my $result = $session->get_request( -varbindlist  => \@staticList);
while (my ($k, $v) = each(%staticOids)) { print $k.": ".$result->{$v}."\n"; }

# determine if logging is required and create the output files
if (DATAOUT) {
  ($workbook, $raw_data, $summary, $hdrfmt, $stdfmt, $fmt2dec, $fmt3dec) = &open_xls($xlsName);
  ($workbook, $raw_data, $summary, %formats) = &open_xls($xlsName);

  # write worksheet headers
  $row = $col = 0;
  $summary->write( $row, $col, \@summaryHdrs, $hdrfmt);
  $raw_data->write($row, $col, \@rawdataHdrs, $hdrfmt);
}



##
## Begin Main
##

# loop until start-of-test is detected
&detect_test($session, \%dataOids) unless BYPASS;

$testStart = Time::HiRes::time();
# start active polling
while ($elapsed <= $testLen) {
  $pollTimer{'start'} = Time::HiRes::time();

  # get current statistics from DUT
  $dataVals = $session->get_request( -varbindlist  => \@dataList);
  die($session->error."\n") if (!defined($dataVals));

  $pollTimer{'datapoll'} = Time::HiRes::time();

  # CPU and Memory utilization
  $cpuTicks   = ($dataVals->{$dataOids{'ssCpuRawUser'}}   - $oldData{'ssCpuRawUser'}) +
                ($dataVals->{$dataOids{'ssCpuRawNice'}}   - $oldData{'ssCpuRawNice'}) + 
                ($dataVals->{$dataOids{'ssCpuRawSystem'}} - $oldData{'ssCpuRawSystem'}) + 
                ($dataVals->{$dataOids{'ssCpuRawIdle'}}   - $oldData{'ssCpuRawIdle'});
  $cpuUsed    = $cpuTicks - ($dataVals->{$dataOids{'ssCpuRawIdle'}} - $oldData{'ssCpuRawIdle'});
  $cpuUtil    = (($cpuUsed / $cpuTicks) * 100);
  $cpuPercent = sprintf("%.2f", $cpuUtil);
  $memUsed    = $dataVals->{$dataOids{'tmmTotalMemoryUsed'}};

  # client and server currnet connections
  $clientCurConns = $dataVals->{$dataOids{'sysStatClientCurConns'}};
  $serverCurConns = $dataVals->{$dataOids{'sysStatServerCurConns'}};

  # update 'old' data with the current values to calculate delta next cycle
  $oldData{'ssCpuRawUser'}   = $dataVals->{$dataOids{'ssCpuRawUser'}};
  $oldData{'ssCpuRawNice'}   = $dataVals->{$dataOids{'ssCpuRawNice'}};
  $oldData{'ssCpuRawSystem'} = $dataVals->{$dataOids{'ssCpuRawSystem'}};
  $oldData{'ssCpuRawIdle'}   = $dataVals->{$dataOids{'ssCpuRawIdle'}};

  $pollTimer{'pollend'} = Time::HiRes::time();

  my $clientBytesIn   = sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientBytesIn'}});
  my $clientBytesOut  = sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientBytesOut'}});
  my $clientPktsIn    = sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientPktsIn'}});
  my $clientPktsOut   = sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientPktsOut'}});
  my $serverBytesIn   = sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerBytesIn'}});
  my $serverBytesOut  = sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerBytesOut'}});
  my $serverPktsIn    = sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerPktsIn'}});
  my $serverPktsOut   = sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerPktsOut'}});
  my $clientTotConns  = sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientTotConns'}});
  my $serverTotConns  = sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerTotConns'}});
  my $clientCurConns  = sprintf("%.0f", $dataVals->{$dataOids{'sysStatClientCurConns'}});
  my $serverCurConns  = sprintf("%.0f", $dataVals->{$dataOids{'sysStatServerCurConns'}});

  $pollTimer{'calcend'} = Time::HiRes::time();
  $runTime = $pollTimer{'calcend'} - $testStart;

  # If requested, write the output file.
  if (DATAOUT) {
    $row++;
    $raw_data->write($row, 0, $runTime, $fmt3dec);
    $raw_data->write($row, 1, $cpuPercent, $fmt2dec);

    $raw_data->write($row, 
                     2, 
                     [$memUsed, $clientBytesIn, $clientBytesOut, $clientPktsIn,
                      $clientPktsOut, $serverBytesIn, $serverBytesOut, 
                      $serverPktsIn, $serverPktsOut,$clientCurConns, $clientTotConns,
                      $serverCurConns, $serverTotConns], 
                     $stdfmt);
  }

  # Calculate how much time this polling cycle has required to determine how
  # long we should sleep before beginning the next cycle
  $pollTimer{'end'} = Time::HiRes::time();

  $pollRTT   = $pollTimer{'datapoll'} - $pollTimer{'start'};
  $timeSpent = $pollTimer{'end'} - $pollTimer{'start'};
  $sleepTime = $cycleTime-$timeSpent;

  DEBUG && printf("DBG: Runtime: %.3f, CPU: %.2f%%, Mem: %dMB, Client conns: %.0f Server conns: %.0f\n",
              $timeSpent, $cpuUtil, ($memUsed / MB), $clientCurConns, $serverCurConns);

#  DEBUG && printf("DBG: Cycle time: %.3f; Poll time: %.4f; Sleeping %.3f; Elapsed: %d\n", 
#              $timeSpent, $pollRTT, $cycleTime, $elapsed);

  $elapsed += $cycleTime;
  usleep($cycleTime * 1000000);
} 


# polling is now complete, time to write the summary data
my $dataRows = $row;
$row = $col = 0;

for ( $row = 1; $row < $dataRows; $row++) {
  $rawRow = $row+1;
  # @rowData contains formulas required to populate the summary data sheet.
  # In order, they are: memutil, client bits/sec in, client bits/sec out,
  #                     server bits/sec in, server bits/sec out, client conns/sec,
  #                     server conns/sec 
  @rowData    = ('=raw_data!C'.($rawRow+1),
                 '=(((raw_data!D'.($rawRow+1).'- raw_data!D'.$rawRow.') / '.$cycleTime.') * 8)',
                 '=(((raw_data!E'.($rawRow+1).'- raw_data!E'.$rawRow.') / '.$cycleTime.') * 8)',
                 '=(((raw_data!H'.($rawRow+1).'- raw_data!H'.$rawRow.') / '.$cycleTime.') * 8)',
                 '=(((raw_data!I'.($rawRow+1).'- raw_data!I'.$rawRow.') / '.$cycleTime.') * 8)',
                 '=((raw_data!M'.($rawRow+1).'- raw_data!M'.$rawRow.') / '.$cycleTime.')',
                 '=((raw_data!O'.($rawRow+1).'- raw_data!O'.$rawRow.') / '.$cycleTime.')',
                );
  # splitting these out is required so a different format can be applied to numbers
  my $rowTime = '=raw_data!A'.($rawRow+1);
  my $rowCPU  = '=raw_data!B'.($rawRow+1);

  $summary->write($row, 0, $rowTime,  $fmt3dec);
  $summary->write($row, 1, $rowCPU,   $fmt2dec);
  $summary->write($row, 2, \@rowData, $stdfmt);

}

# close the excel workbook
&close_xls($workbook);



##
## Subs
##

# delay the start of the script until the test is detected
# detect the test using client packet/sec 
sub detect_test() {
  my $snmp  = shift;
  my $oids  = shift;

  print STDOUT "Waiting for test to begin...";
  while (1) {

    my $result1 = $snmp->get_request($$oids{'sysStatClientPktsIn'});
    sleep(2);
    my $result2 = $snmp->get_request($$oids{'sysStatClientPktsIn'});

    my $delta = $result2->{$$oids{'sysStatClientPktsIn'}}- 
                $result1->{$$oids{'sysStatClientPktsIn'}};
  
    if ( $delta > 500 ) {
      print "\nTest start detected. Beginning active polling...\n";
      return;
    }
    else {
      print ".";
      sleep(3);
    }
  }
}


## returns a has containing the data-oids
sub get_f5_oids() {
  my %oidlist = (
      'ssCpuRawUser'            => '.1.3.6.1.4.1.2021.11.50.0',
      'ssCpuRawNice'            => '.1.3.6.1.4.1.2021.11.51.0',
      'ssCpuRawSystem'          => '.1.3.6.1.4.1.2021.11.52.0',
      'ssCpuRawIdle'            => '.1.3.6.1.4.1.2021.11.53.0',
      'tmmTotalMemoryUsed'      => '.1.3.6.1.4.1.3375.2.1.1.2.1.45.0',
      'sysStatClientBytesIn'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.3.0',
      'sysStatClientBytesOut'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.5.0',
      'sysStatClientPktsIn'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.2.0',
      'sysStatClientPktsOut'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.4.0',
      'sysStatClientTotConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.7.0',
      'sysStatClientCurConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.8.0',
      'sysStatServerBytesIn'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.10.0',
      'sysStatServerBytesOut'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.12.0',
      'sysStatServerPktsIn'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.9.0',
      'sysStatServerPktsOut'    => '.1.3.6.1.4.1.3375.2.1.1.2.1.11.0',
      'sysStatServerTotConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.14.0',
      'sysStatServerCurConns'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.15.0',
                );

  return(%oidlist);
}

# returns a hash containing oids that will be polled only once
sub get_static_oids() {
  my %oidlist = ( 'ltmVersion'   => '.1.3.6.1.4.1.3375.2.1.4.2.0',
                  'platform'     => '.1.3.6.1.4.1.3375.2.1.3.3.1.0',
                  'cpuCount'     => '.1.3.6.1.4.1.3375.2.1.1.2.1.38.0',
                  'totalMemory'  => '.1.3.6.1.4.1.3375.2.1.1.2.1.44.0',
                );

  return(%oidlist);
}

# returns a has containing oids that track errors
sub get_err_oids() {
  my %oidlist = (
      'vipNonSynDeny'       => '.1.3.6.1.4.1.3375.2.1.1.2.21.20.0',
      'cmpConnRedirected'   => '.1.3.6.1.4.1.3375.2.1.1.2.21.23.0',
      'connMemErrors'       => '.1.3.6.1.4.1.3375.2.1.1.2.21.24.0',
      'DroppedPackets'      => '.1.3.6.1.4.1.3375.2.1.1.2.21.30.0',
      'incomingPktErrors'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.47.0',
      'outgoingPktErrors'   => '.1.3.6.1.4.1.3375.2.1.1.2.1.48.0',
  );

  return(%oidlist);
}


sub open_xls() {
  my $fname = shift;

  ## create Excel workbook
  my $workbook = Spreadsheet::WriteExcel->new($fname);

  # define formatting
  my $hdrfmt  = $workbook->add_format(align => 'center', bold => 1, bottom => 1);
  my $stdfmt  = $workbook->add_format(align => 'center', num_format => '#,##0');
  my $fmt2dec = $workbook->add_format(align => 'center', num_format => '0.00');
  my $fmt3dec = $workbook->add_format(align => 'center', num_format => '0.000');

  # create worksheets
  my $summary = $workbook->add_worksheet('summary');
  $summary->set_column('A:A', 9);
  $summary->set_column('B:B', 7);
  $summary->set_column('C:M', 17);
  $summary->activate();

  my $rawdata = $workbook->add_worksheet('raw_data');
  $rawdata->set_column('A:B', 9);
  $rawdata->set_column('C:Z', 15);

  return($workbook, $rawdata, $summary, $hdrfmt, $stdfmt, $fmt2dec, $fmt3dec);
}

# Close the spreadsheet -- REQUIRED
sub close_xls() {
  my $xls = shift;

  $xls->close();

  return(1);
}

# print script usage and exit with the supplied status
sub usage() {

  print <<END;
  USAGE:  $0 -d <host> -l <total test length> -f <output file>
          $0 -h

  -d      IP or hostname to query (REQUIRED)
  -l      Full Test duration      (default: 140 seconds)
  -f      Output filename         (default: /dev/null, will provide basic statistics to CLI)
  -h      Print usage and exit

END
}
