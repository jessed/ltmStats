#! /bin/bash

host=c103-4

OIDS="sysStatTmTotalCycles sysStatTmIdleCycles sysStatTmSleepCycles sysStatClientPktsIn"
OIDS="$OIDS sysStatClientBytesIn sysStatClientPktsOut sysStatClientBytesOut sysStatClientTotConns"
OIDS="$OIDS sysStatServerPktsIn sysStatServerBytesIn sysStatServerPktsOut sysStatServerBytesOut"
OIDS="$OIDS sysStatServerTotConns"
LIST=''


MIB="F5-BIGIP-SYSTEM-MIB"

for i in $OIDS; do
  #snmpget -On $host $MIB::${i}.0
  LIST="$LIST $MIB::${i}.0"
done

snmpget -On $host $LIST
snmpget $host $LIST
