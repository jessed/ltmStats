#! /usr/bin/perl -w

use strict;
use SNMP;
use Spreadsheet::WriteExcel;
use Time::HiRes qw(sleep usleep);
use Data::Dumper;

my $host    = 'c103-4';
my $snmpVer = '2c';
my $comm    = 'public';
#my @oids    = &mk_oids();
my $oids    = &mk_oids();

print "OIDS: ".Dumper($oids)."\n\n";

my $session = new SNMP::Session(DestHost => $host, 
                                Community => $comm,
                                Version   => $snmpVer,
                               );

if ($session->{ErrorNum}) { die("ERROR:".$session->{ErrorStr}."\n"); }
SNMP::initMib();

my @vals  = $session->get($oids);
#print "final 'vals': ".Dumper(\@vals);
foreach (@vals) {
  print $_."\n";
}




##
## Subs
##

sub mk_oids() {
  my @snmp  = ();
  my $BIGIP_SYSTEM  = "F5-BIGIP-SYSTEM-MIB";

  my @TMM_STATS     = qw(sysStatTmTotalCycles sysStatTmIdleCycles sysStatTmSleepCycles);
  my @CLIENT_STATS  = qw(sysStatClientPktsIn sysStatClientBytesIn sysStatClientPktsOut
                         sysStatClientBytesOut sysStatClientTotConns);
  my @SERVER_STATS  = qw(sysStatServerPktsIn sysStatServerBytesIn sysStatServerPktsOut
                         sysStatServerBytesOut sysStatServerTotConns);

  for (@CLIENT_STATS) { push(@snmp, [$BIGIP_SYSTEM.'::'.$_,0]); }
  for (@SERVER_STATS) { push(@snmp, [$BIGIP_SYSTEM.'::'.$_,0]); }

  my $vars = new SNMP::VarList(@snmp);
  return($vars);
}


# generate and return a varList
sub get_oid_list() {
  my $BIGIP_SYSTEM  = "F5-BIGIP-SYSTEM-MIB";

  # UCD oids
  my $numCPUs       = 'sysStatCpuCount.0';
  my $cpuUser       = 'ssCpuUser.0';
  my $cpuSystem     = 'ssCpuSystem.0';
  my $cpuIdle       = 'ssCpuIdle.0';

  # F5 oids
  my $totalMemory     = 'sysStatMemoryTotal.0';
  my $usedMemory      = 'sysStatMemoryUsed.0';

  # client-side network
  my $clientPktsIn    = 'sysStatClientPktsIn.0';
  my $clientBytesIn   = 'sysStatClientBytesIn.0';
  my $clientPktsOut   = 'sysStatClientPktsOut.0';
  my $clientBytesOut  = 'sysStatClientBytesOut.0';
  my $clientTotConns  = 'sysStatClientTotConns.0';

  # server-side network
  my $serverPktsIn    = 'sysStatServerPktsIn.0';
  my $serverBytesIn   = 'sysStatServerBytesIn.0';
  my $serverPktsOut   = 'sysStatServerPktsOut.0';
  my $serverBytesOut  = 'sysStatServerBytesOut.0';
  my $serverTotConns  = 'sysStatServerTotConns.0';

}
  
